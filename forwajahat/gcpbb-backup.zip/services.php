<!doctype html>
<html lang="en">
<head>
<title>Start a Business, Protect Your Brand, Trademark Incorporate & More Online | gcpbb.co.uk | Global Copyrights Protection Bureau for Brands</title>
<meta name="keywords" content="">
<meta name="description" content="">

<?php
$style = $_SERVER['HTTP_HOST']; 
$style = "includes/style.php"; 
include($style); 
?>

<?php
$urhere = "services";
?>


</head>
<body class="inner-pages innerservices">

<?php
$header = $_SERVER['HTTP_HOST']; 
$header = "includes/header.php"; 
include($header); 
?>


<section class="innerbanner  d-flex" style="background-image:url(assets/images/banners/innerpgbanner.png)">
  <div class="container align-self-center">
    <div class="row">
      <div class="col-lg-12">
        <div class="text-wrap">
          <h5>Intellectual Property</h5>
          <h1>Make sure your work is protected</h1>
          <p>Whether you need a copyright, trademark or patent, we can help make the process easy and affordable.</p>
        </div>
      </div>
    </div>
  </div>
</section>



<section class="cta-guide">
  <div class="container">
    <div class="row">
      <div class="col-lg-3">
        <figure class="splash-one">
          <img src="assets/images/paperplane-man-banner.svg">
        </figure>
      </div>
      <div class="col-lg-6">
        <div class="mid-wrap">
          <h3>Not sure which type of protection you need?<span>Let us guide you.</span></h3>
          <a href="javascript:;" class="btn-theme">Help Me Decide</a>
        </div>
      </div>
      <div class="col-lg-3">
        <figure class="splash-two">
          <img src="assets/images/mountain-range-banner.svg">
        </figure>
      </div>
    </div>
  </div>
</section>



<section class="innerboxes ">
  <div class="container">
    <div class="row">
      <div class="col-lg-12">
        <ul class="boxeswrap">
          <li>
            <figure>
              <img src="assets/images/box-1.png">
              <div class="hovertext">
                <h6>Trademark Registration</h6>
              </div>
            </figure>
            <div class="textwrapper">
              <p>A provisional application for patent establishes your priority filing date...</p>
              <a href="<?php echo $path;?>trademark-registration" class="btn-theme">Learn More</a>
            </div>
          </li>
          
          <li class="mid">
            <figure>
              <img src="assets/images/box-2.png">
              <div class="hovertext">
                <h6>Brand Patent</h6>
              </div>
            </figure>
            <div class="textwrapper">
              <p>A provisional application for patent establishes your priority filing date...</p>
              <a href="<?php echo $path;?>brand-patent" class="btn-theme">Learn More</a>
            </div>
          </li>

          <li>
            <figure>
              <img src="assets/images/box-3.png">
              <div class="hovertext">
                <h6>Copyright Registration</h6>
              </div>
            </figure>
            <div class="textwrapper">
              <p>Your business name helps establish your brand. Make it yours. Make it memorable...</p>
              <a href="<?php echo $path;?>copyright-registration" class="btn-theme">Learn More</a>
            </div>
          </li>
          <!-- <li>
            <figure>
              <img src="assets/images/box-1.jpg">
              <div class="hovertext">
                <h6>Trademark Registration</h6>
              </div>
            </figure>
            <div class="textwrapper">
              <p>File for the exclusive rights to a name, slogan or symbol that identifies your business or brand.</p>
              <a href="javascript:;" class="btn-theme">Learn More</a>
            </div>
          </li>
          <li class="mid">
            <figure>
              <img src="assets/images/box-1.jpg">
              <div class="hovertext">
                <h6>Trademark Registration</h6>
              </div>
            </figure>
            <div class="textwrapper">
              <p>File for the exclusive rights to a name, slogan or symbol that identifies your business or brand.</p>
              <a href="javascript:;" class="btn-theme">Learn More</a>
            </div>
          </li>
          <li>
            <figure>
              <img src="assets/images/box-1.jpg">
              <div class="hovertext">
                <h6>Trademark Registration</h6>
              </div>
            </figure>
            <div class="textwrapper">
              <p>File for the exclusive rights to a name, slogan or symbol that identifies your business or brand.</p>
              <a href="javascript:;" class="btn-theme">Learn More</a>
            </div>
          </li> -->
        </ul>
      </div>
    </div>
  </div>
</section>

<!-- <section class="packagesSec">
  <div class="topwrapper">
    <h2>Which IP protection is right for you?</h2>
    <p>View full comparison chart</p>
  </div>
  <div class="container">
    <div class="row">
      <div class="packboxes">
        <div class="customcol colu3">
          <h3>Copyright</h3>
          <ul>
            <li class="check">Protects original works of authorship</li>
            <li>Protects a name, slogan, or symbol that identifies a business or brand</li>
            <li>Protects an original invention's functional characteristics</li>
            <li class="check">Protects the original ornamental design of an article of manufacture</li>
          </ul>

          <a href="javascript:;">Get Started</a>

        </div>

        <div class="customcol colu3">
          <h3>Trademark</h3>
          <ul>
            <li>Protects original works of authorship</li>
            <li class="check">Protects a name, slogan, or symbol that identifies a business or brand</li>
            <li>Protects an original invention's functional characteristics</li>
            <li>Protects the original ornamental design of an article of manufacture</li>
          </ul>

          <a href="javascript:;">Get Started</a>

        </div>

        <div class="customcol colu3">
          <h3>Utility Patent</h3>
          <ul>
            <li>Protects original works of authorship</li>
            <li>Protects a name, slogan, or symbol that identifies a business or brand</li>
            <li class="check">Protects an original invention's functional characteristics</li>
            <li>Protects the original ornamental design of an article of manufacture</li>
          </ul>

          <a href="javascript:;">Get Started</a>

        </div>

        <div class="customcol colu3">
          <h3>Design Patent</h3>
          <ul>
            <li>Protects original works of authorship</li>
            <li>Protects a name, slogan, or symbol that identifies a business or brand</li>
            <li>Protects an original invention's functional characteristics</li>
            <li class="check">Protects the original ornamental design of an article of manufacture</li>
          </ul>

          <a href="javascript:;">Get Started</a>

        </div>
      </div>
    </div>
  </div>
</section> -->

<?php
$askawaywrapper = $_SERVER['HTTP_HOST']; 
$askawaywrapper = "includes/askawaywrapper.php"; 
include($askawaywrapper); 
?>



<section class="helpinfo">
  <div class="container">
    <div class="row">
      <div class="topwrapper">
        <h2>Helpful Information</h2>
      </div>
      <div class="col-lg-6">
        <h4>Definition of a copyright</h4>
        <p>A copyright is a form of protection that prevents others from copying, performing or otherwise using an original work of authorship without the copyright holder's consent.  <a href="javascritp:;">Read full article</a></p>

        <h4>Introduction to trademarks</h4>
        <p>Trademarks are important business tools because they allow companies to establish a brand for their goods and services without having to worry about other companies diminishing their reputation or profit by deceiving consumers.  <a href="javascritp:;">Read full article</a></p>
      </div>
      <div class="col-lg-6">
        <h4>Searching for conflicting trademarks</h4>
        <p>It's highly advisable to search for conflicting trademarks before submitting a trademark application, because existing trademarks that conflict with yours may result in your application being denied.  <a href="javascritp:;">Read full article</a></p>

        <h4>What can be patented?</h4>
        <p>Under U.S. patent law, any person who "invents or discovers any new and useful process, machine, manufacture, or composition of matter, or any new and useful improvement thereof, may obtain a patent."  <a href="javascritp:;">Read full article</a></p>
      </div>
    </div>
  </div>
</section>




<section class="testimonials">
  <div class="container">
    <div class="row">
      <div class="testslide">
        <div class="item">
          <h3>"I'm an independent artist who needed a way to protect myself and my living. Global Copyrights Protection Bureau for Brands made the process easy and I couldn't be happier with the results!"</h3>
          <p><b>- Alex O.</b>, Boston, MA</p>
        </div>
      </div>
    </div>
  </div>
</section>



<section class="registerwrapper">
  <div class="container">
    <div class="row">
      <div class="registertext">
        <div class="item">
          <p><strong>Intellectual Property Protection – Register a Trademark or Copyright, Apply for a Patent</strong></p>
          <p class="below">Protecting your <strong>intellectual property</strong> is important because it prevents others from capitalizing on your creativity and hard work.&nbsp;Global Copyrights Protection Bureau for Brands can help you with a wide variety of <strong>IP services</strong> to protect your idea, invention, or original work of art.&nbsp;The three main types of intellectual property protection are <strong>trademarks</strong>, <strong>copyrights</strong>, and <strong>patents</strong>. If you are a business owner who is interested in protecting your business name or logo, you may want to apply for trademark registration.&nbsp;Before spending time and money applying to <strong>register a trademark</strong>, a comprehensive trademark search is recommended to determine its availability. A comprehensive <strong>trademark search</strong> looks for any trademarks that may be similar to yours, including those with different spellings. Protection of your books, songs, photographs or other original works of authorship will be enhanced if you register a copyright.&nbsp; <strong>Copyright registration</strong> helps you establish a public record of the copyright claim and allows you to enforce your copyright in federal court. If you want to <strong>patent an idea</strong>, you'll need to start by turning your idea into an actual invention.&nbsp; You may then want to file a provisional application for patent to establish your priority filing date with the <strong>U.S. Patent and Trademark Office (USPTO)</strong> which allows you to immediately start labeling your invention "<strong>patent pending</strong>".&nbsp; Global Copyrights Protection Bureau for Brands can help make the process of applying for a utility patent or design patent easy and affordable.&nbsp; Start protecting your intellectual property by registering a trademark or copyright, filing a patent, or by submitting a provisional patent application online through Global Copyrights Protection Bureau for Brands.&nbsp;    </p>
        </div>
      </div>
    </div>
  </div>
</section>


<section class="innercta">
  <div class="container">
    <div class="row">
      <div class="col-lg-12">
        <div class="formwrap">
          <div class="textwrapper">
            <h3>Get helpful tips and info from our newsletter!</h3>
          </div>
          <div class="subscribeform">
            <form class="" id="banform"  method="POST" action="webpages/bannerFormController.php">
              
                <div class="wrap">
                  <div class="dtf">
                    <input id="fname" name="Search" minlength="5" class="round" type="text" placeholder="Your Email Address" required />
                  </div>
                  
                  <div class="dtf btnpart text-left">
                    <input class="submit" type="submit" value="Submit" />
                  </div>
                </div>

              
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>


<?php
$footer = $_SERVER['HTTP_HOST']; 
$footer = "includes/footer.php"; 
include($footer); 
?>




<!-- scroll top car
<div class="car-top"><span>
<img src="assets/images/car.png" alt="Top" title="Back to top" />
</span></div>
-->
</body>
</html>