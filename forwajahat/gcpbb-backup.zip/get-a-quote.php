<!doctype html>
<html lang="en">
<head>
<title>Hire us to Get Started! Ghost Writers is the way to go. - Global Copyrights</title>

<meta name="keywords" content="">
<meta name="description" content="">

<?php
$style = $_SERVER['HTTP_HOST']; 
$style = "includes/style.php"; 
include_once($style); 
?>

 <style>
  body{background:#f7f9fc}   
 </style>


</head>
<body class="analyzepg">

<section class="tphead" style="background:#f7f9fc;">
  <div class="container">
    <div class="row">
      <div class="col-lg-2">
        <div class="logo">
            <a href="/">
              <img class="img-fluid black" src="assets/images/glogo.svg" alt="*" />
            </a>
          </div>
      </div>
      <div class="col-lg-10">
        <div class="text-right">
          <a href="/" class="close"><span class="icon-x-square"></span></a>
        </div>
      </div>
    </div>
  </div>
</section>


<section class="">
        <div class="get-form " style="background:#f7f9fc;height: 76vh;">
          <div class="container ">
            <div class="row">
              <div class="col-lg-8 offset-lg-2 col-xl-8 text-center">
                <div class="form-content">
                  <!-- <h3 class="john">We would like to hear from you</h3>
                  <p>Heads up! We require that you sign up for a Reseller Prohub services and packages. We make all your dreams come true in a successful project.</p> -->
                  
                  <div class="col-lg-10 offset-lg-1 multiplesteps-form text-left mt-10">
                      <?php
                      $contactfrm = $_SERVER['HTTP_HOST']; 
                      $contactfrm = "includes/contactfrm.php"; 
                      include_once($contactfrm); 
                      ?> 
          
                  </div>

                  
              </div>
            </div>
          </div>
        </div>

</section>

                
    






<script src="assets/js/mlib.js"></script> 
<script src="assets/js/functions.js"></script> 



<!-- scroll top car
<div class="car-top"><span>
<img src="assets/images/car.png" alt="Top" title="Back to top" />
</span></div>
-->
</body>
</html>