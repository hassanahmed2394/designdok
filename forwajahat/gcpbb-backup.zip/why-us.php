<!doctype html>
<html lang="en">
<head>
<title>Start a Business, Protect Your Brand, Trademark Incorporate & More Online | gcpbb.co.uk | Global Copyrights Protection Bureau for Brands</title>
<meta name="keywords" content="">
<meta name="description" content="">

<?php
$style = $_SERVER['HTTP_HOST']; 
$style = "includes/style.php"; 
include($style); 
?>

<?php
$urhere = "why-us";
?>


</head>
<body class="inner-pages innerservices">

<?php
$header = $_SERVER['HTTP_HOST']; 
$header = "includes/header.php"; 
include($header); 
?>


<section class="innerbanner d-flex rightimg">
  <div class="container align-self-center">
    <div class="row">
      <div class="col-lg-5">
        <div class="textarea">
          <h1>You've got an ally</h1>
          <p>We're in the business of providing clarity—whether you use our simplified self-guided legal services or work with one of our fantastic independent attorneys, or both, we've got your back.</p>
        </div>
      </div>
      <div class="col-lg-7">
        <figure class="rightfigbanner">
          <img src="assets/images/why-us-hero.svg">
        </figure>
      </div>
    </div>
  </div>
</section>

<section class="howdoes">
  <div class="container">
    <div class="row">
      <div class="col-lg-12">
        <h2>How does it work?</h2>

      </div>
      <div class="col-lg-4">
        <div class="boxx">
          <figure>
            <img src="assets/images/icon1.svg">
          </figure>
          <h3>We handle forms and filing</h3>
          <p>So long, red tape. All you need to do is answer one of our simplified questionnaires and we'll do the (not so) fun part.</p>
        </div>
      </div>
      <div class="col-lg-4">
        <div class="boxx">
          <figure>
            <img src="assets/images/icon2.svg">
          </figure>
          <h3>We charge flat fees</h3>
          <p>We'll never "send the bill." Get help in business formation, contracts, estate planning, trademarks, and other self-guided services without getting charged by the hour.</p>
        </div>
      </div>
      <div class="col-lg-4">
        <div class="boxx">
          <figure>
            <img src="assets/images/icon3.svg">
          </figure>
          <h3>We have vetted attorneys</h3>
          <p>Who said attorneys are intimidating? Many people did, so we spent a lot of time finding topnotch ones who are friendly and speak in plain English (yes, they do exist!).</p>
        </div>
      </div>
    </div>
  </div>
</section>

<section class="commitmentsec">
  <div class="container">
    <div class="row">
      <div class="col-lg-4">
        <figure class="comfig">
          <img src="assets/images/our-commitment.svg">
        </figure>
      </div>
      <div class="col-lg-8">
        <div class="text">
          <h2>Our commitment</h2>
          <p>There's no "been meaning to do that for years," "I don't know where to even begin," or half-completed task we can't handle. And not just for legal stuff. We're also here to connect you to help for your other least favorite thing—taxes.</p>
          <p>You're never alone—our Customer Care agents, independent network of attorneys, and tax pro service partner are along for the ride. Call, email, or chat if you ever need support (or a pep talk).</p>
        </div>
      </div>
    </div>
  </div>
</section>


<section class="pledgesec">
  <div class="container">
    <div class="row">
      <div class="col-lg-12">
        <h2>Our pledge to peace of mind</h2>
        <article>
          <div class="bannerdiv">
            <p>We stand behind our commitment—that's why our  <span>100% Satisfaction Guarantee </span>promises that we get it right or you get your money back.</p>
          </div>
        </article>
      </div>
    </div>
  </div>
</section>
<section class="cta-guide">
  <div class="container">
    <div class="row">
      <div class="col-lg-3">
        <figure class="splash-one">
          <img src="assets/images/paperplane-man-banner.svg">
        </figure>
      </div>
      <div class="col-lg-6">
        <div class="mid-wrap">
          <h3>Not sure which type of protection you need?<span>Let us guide you.</span></h3>
          <a href="javascript:;" class="btn-theme">Help Me Decide</a>
        </div>
      </div>
      <div class="col-lg-3">
        <figure class="splash-two">
          <img src="assets/images/mountain-range-banner.svg">
        </figure>
      </div>
    </div>
  </div>
</section>

<section class="mytestimonials">
  <div class="container">
    <div class="row">
      <div class="col-lg-12">
        <div class="mytestwrap">
          <article>
            <div class="fighead">
              <figure>
                <img src="assets/images/derek-rohlff.png">
              </figure>
            </div>
            <div class="textwtrap">
              <p>"I am a part of a novel approach to the practice of law that is revolutionizing the industry. Global Copyrights Protection Bureau for Brands definitely works to fill the gap between the need for an attorney and access to an attorney, and it is really powerful."</p>
              <h6>Mary Beaghler Penn, Global Copyrights Protection Bureau for Brands Legal Plan Attorney*</h6>
            </div>
          </article>
        </div>
      </div>
    </div>
  </div>

</section>


<section class="bluecta">
  <div class="container">
    <div class="row">
      <div class="col-lg-12">
        <div class="left">
          <h3>Ready to work together? Let's go!</h3>
        </div>
        <div class="right">
          <a href="javascript:;">Live Chat</a>
          <a class="outline" href="tel:+44-144-290-2191 ">+44-144-290-2191 </a>
        </div>
      </div>
    </div>
  </div>
</section>

<section class="ourinspiration">
  <div class="container">
    <div class="row">
      <div class="col-lg-12">
        <h2>Our inspiration</h2>
        <div class="inspiration">
          <div class="imagecontainer">
            
          </div>
          <div class="inspirationcontainer">
            <div class="heading">
              <h3>McCalls Meat and Fish Co. <span>Formed their LLC</span></h3>
            </div>
            <div class="inspiration-text">
              <p>"We went to Global Copyrights Protection Bureau for Brands right off the bat, because everything my husband and I have done in this business we have figured out ourselves—everything from HR to finance to the legal parts. We've used them for quite a few things over the years, and overall it's gone very smoothly. They've been easy to work with and very affordable."</p>
              <h6>Karen Yoo, Co-owner, McCalls Meat and Fish Co.</h6>
            </div>
          </div>
        </div>

        <div class="inspiration rightside">
          <div class="imagecontainer">
            
          </div>
          <div class="inspirationcontainer">
            <div class="heading">
              <h3>Mamma Chia <span>Formed her LLC</span></h3>
            </div>
            <div class="inspiration-text">
              <p>"I had never started a business before, so Global Copyrights Protection Bureau for Brands was a perfect place to go. It let me take my vision for the company and make it a reality, legally."</p>
              <h6>Janie Hoffman, CEO and Founder of Mamma Chia</h6>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>



<?php
$askawaywrapper = $_SERVER['HTTP_HOST']; 
$askawaywrapper = "includes/askawaywrapper.php"; 
include($askawaywrapper); 
?>





<?php
$footer = $_SERVER['HTTP_HOST']; 
$footer = "includes/footer.php"; 
include($footer); 
?>




<!-- scroll top car
<div class="car-top"><span>
<img src="assets/images/car.png" alt="Top" title="Back to top" />
</span></div>
-->
</body>
</html>