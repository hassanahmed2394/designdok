<!doctype html>
<html lang="en">
<head>
<title>Start a Business, Protect Your Brand, Trademark Incorporate & More Online | gcpbb.co.uk | Global Copyrights Protection Bureau for Brands</title>
<meta name="keywords" content="">
<meta name="description" content="">

<?php
$style = $_SERVER['HTTP_HOST']; 
$style = "includes/style.php"; 
include($style); 
?>

<?php
$urhere = "services";
?>


</head>
<body class="inner-pages innerservices">

<?php
$header = $_SERVER['HTTP_HOST']; 
$header = "includes/header.php"; 
include($header); 
?>


<section class="innerbanner d-flex patentbanner" style="background-image:url(assets/images/banners/brand-patent.png)">
  <div class="container align-self-center">
    <div class="row">
      <div class="col-lg-6">
        <div class="text-wrap">
          <h1>Build your brand with a DBA</h1>
          <p>Your business name helps establish your brand. Make it yours. Make it memorable.</p>
          <a href="<?php echo $path;?>get-a-quote" class="btn-theme">Start my DBA</a>
          <h6>Price starts at £299.00 + state filing fees</h6>
          <div class="btnwrap">
            <a href="tel:+441442902191" class="call">+44-144-290-2191 </a>
            <a href="javascript:;" onclick="setButtonURL();" class="chat">Live Chat</a>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<section class="starsreview">
  <div class="container">
    <div class="row">
      <div class="col-lg-12">
        <div class="reviews">
          <div class="stars">
            <i class="icon-star"></i>
            <i class="icon-star"></i>
            <i class="icon-star"></i>
            <i class="icon-star"></i>
            <i class="icon-star-half-full"></i>
          </div>
          <div class="ratings">
            <h3>4.4 (4369)</h3>
          </div>
        </div>
        <!-- <div class="btnwrapper">
          <a href="<?php echo $path;?>get-a-quote" class="left">Read user reviews</a>
          <a href="<?php echo $path;?>get-a-quote">Ask a question</a>
        </div> -->
      </div>
    </div>
  </div>
</section>

<section class="whyget">
  <div class="container">
    <div class="row">
      <div class="col-lg-12">
      <h2>Why get a "doing business as" name?</h2>
        <ul class="mythreeboxes">
          <li>
            <figure>
              <img src="assets/images/secure-icon.svg">
            </figure>
            <h4>Comply with legal requirement</h4>
            <p>A DBA filing may be required if you're using a name other than your official name or personal name.</p>
          </li>
          <li>
            <figure>
              <img src="assets/images/build-a-foundation-icon.svg">
            </figure>
            <h4>Set up a business bank account</h4>
            <p>In most states, you need a DBA to open a bank account under your business name.</p>
          </li>
          <li>
            <figure>
              <img src="assets/images/expand-your-business.svg">
            </figure>
            <h4>Expand and grow your business</h4>
            <p>A DBA helps distinguish new business lines to market, manage, and grow your business.</p>
          </li>
        </ul>
      </div>
    </div>
  </div>
</section>


<section class="go-beyond">
  <div class="container">
    <div class="row imageswrapper">
      <div class="col-lg-6">
        <figure><img src="assets/images/measuring.png" alt=""></figure>
      </div>
      <div class="col-lg-6">
        <figure><img src="assets/images/writing.jpg" alt=""></figure>
      </div>
      <div class="col-lg-12 gb-textwrapper">
        <h2>We go beyond just filing the application</h2>
        <div class="go-beyond-wrapper">
          <div class="box">
            <h3>We know the process</h3>
            <p>We've completed and filed over 175,000 DBAs and have relationships with government officials in your state - our team is dedicated to making sure the job gets done right.</p>
          </div>
          <div class="box">
            <h3>We take care of the publishing</h3>
            <p>Some states and counties have other requirements, like publishing notice of your new name in an approved newspaper and providing proof of publication to the appropriate agency. We take care of that for you.</p>
          </div>
          <div class="box">
            <h3>We'll help you find a great name</h3>
            <p>We do a thorough search to check if your name is available. If it isn't, we'll help you find one that is.</p>
          </div>
          <div class="box">
            <h3>Attorney help if you want it</h3>
            <p>If talking to an attorney gives you peace of mind or, if you have specific legal questions, our network of independent attorneys is at your service.*</p>
          </div>
          <div class="col-lg-12 textcenter">
            <p class="centerlink">*Must be a  <a href="<?php echo $path;?>get-a-quote">Business Advisory Plan</a> member</p>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>





<section class="faqs">
  <div class="container">
    <div class="row">
      <div class="offset-lg-2 col-lg-8">
        <h2>Got more questions?</h2>
        <div class="accordion faqs-accordion">
            <div class="quest-section"> <a class="quest-title" href="#faqs-accordion-1">What are the rights of a copyright owner? </a>
              <div id="faqs-accordion-1" class="quest-content">
                <p>The owner of a copyright has the exclusive right to reproduce, distribute copies (for sale or otherwise), publicly perform or display, or create derivative works of the copyrighted work.They also have the right to authorize others to do the same.</p>
              </div>
            </div>
            <div class="quest-section"> <a class="quest-title" href="#faqs-accordion-2">How long does a design patent last?</a>
              <div id="faqs-accordion-2" class="quest-content">
                <p>The term of a design patent is 14 years, beginning on the date the patent is granted. This is in contrast to a utility patent term, which typically lasts 20 years and is measured from the application priority filing date. Design patents are not renewable and require no maintenance fees.  </p>
              </div>
            </div>
            <div class="quest-section"> <a class="quest-title" href="#faqs-accordion-3">How long will it take to prepare my design patent application? </a>
              <div id="faqs-accordion-3" class="quest-content">
                <p>The process of preparing the application and technical drawings generally takes 2-3 weeks. Once the application is filed, you may legally label your design "patent pending" for the period that your application is awaiting approval.</p>
              </div>
            </div>
            <div class="quest-section"> <a class="quest-title" href="#faqs-accordion-4">What's the difference between a copyright and a trademark?</a>
              <div id="faqs-accordion-4" class="quest-content">
                <p>Copyrights generally protect artistic works, such as songs, paintings, books, and audiovisual works. Trademarks are generally used to protect brand names, slogans, and logos for businesses.</p>
              </div>
            </div>
            <div class="quest-section"> <a class="quest-title" href="#faqs-accordion-5">What works are protected by copyright?</a>
              <div id="faqs-accordion-5" class="quest-content">
                <p>Copyright protects "original works of authorship" that are fixed in a tangible form including the following: Literary works Musical works, including any accompanying words Dramatic works, including any accompanying music Pantomimes and choreographic works Pictorial, graphic and sculptural works Motion pictures and other audiovisual works Sound recordings Architectural works These categories should be viewed broadly. For example, computer code and many "compilations" may be registered as "literary works." Maps and architectural plans may be registered as "pictorial, graphic and sculptural works."</p>
              </div>
            </div>
          </div>
      </div>
    </div>
  </div>
</section>



<section class="answer-fold">
  <div class="container">
    <div class="row">
      <h2>Didn’t find the answer you need?</h2>
      <div class="col-lg-8 offset-lg-2">
        <div class="answer-boxwrapper">
          <div class="answer-box">
            <figure><img src="assets/images/customer-care.jpg" alt=""></figure>
            <h4>Call us</h4>
            <a href="javascript:;">+44-144-290-2191 </a>
            <p class="small">Mon-Fri 5am to 7pm PT <br> Weekends 7am to 4pm PT</p>
            
          </div>
          <div class="answer-box">
            <figure><img src="assets/images/attorney.jpg" alt=""></figure>
            <h4>Speak with an attorney</h4>
            <p class="green">No fees, no hourly rates</p>
            <p class="small">Get legal advice from an independent attorney at a price you can afford.</p>
            <a href="javascript:;" class="small">Find out more</a>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>



<section class="big-cta">
  <div class="container">
    <div class="row">
      <div class="col-lg-12">
        <h2>Ready to start your DBA?</h2>
        <a href="<?php echo $path;?>get-a-quote" class="btn-theme">Get Started</a>
      </div>
    </div>
  </div>
</section>




<?php
$patentpackage = $_SERVER['HTTP_HOST']; 
$patentpackage = "includes/patentpackage.php"; 
include($patentpackage); 
?>

<section class="cta-guide">
  <div class="container">
    <div class="row">
      <div class="col-lg-3">
        <figure class="splash-one">
          <img src="assets/images/paperplane-man-banner.svg">
        </figure>
      </div>
      <div class="col-lg-6">
        <div class="mid-wrap">
          <h3>Not sure which type of protection you need?<span>Let us guide you.</span></h3>
          <a href="javascript:;" onclick="setButtonURL();" class="btn-theme">Help Me Decide</a>
        </div>
      </div>
      <div class="col-lg-3">
        <figure class="splash-two">
          <img src="assets/images/mountain-range-banner.svg">
        </figure>
      </div>
    </div>
  </div>
</section>


<?php
// $askawaywrapper = $_SERVER['HTTP_HOST']; 
// $askawaywrapper = "includes/inner-askawaywrapper.php"; 
// include($askawaywrapper); 
?>



<section class="helpinfo">
  <div class="container">
    <div class="row">
      <div class="topwrapper">
        <h2>Helpful Information</h2>
      </div>
      <div class="col-lg-6">
        <h4>Definition of a copyright</h4>
        <p>A copyright is a form of protection that prevents others from copying, performing or otherwise using an original work of authorship without the copyright holder's consent.  <a href="javascritp:;">Read full article</a></p>

        <h4>Introduction to trademarks</h4>
        <p>Trademarks are important business tools because they allow companies to establish a brand for their goods and services without having to worry about other companies diminishing their reputation or profit by deceiving consumers. </p>
      </div>
      <div class="col-lg-6">
        <h4>Searching for conflicting trademarks</h4>
        <p>It's highly advisable to search for conflicting trademarks before submitting a trademark application, because existing trademarks that conflict with yours may result in your application being denied. </p>

        <h4>What can be patented?</h4>
        <p>Under U.K. patent law, any person who "invents or discovers any new and useful process, machine, manufacture, or composition of matter, or any new and useful improvement thereof, may obtain a patent." </p>
      </div>
    </div>
  </div>
</section>




<section class="testimonials">
  <div class="container">
    <div class="row">
      <div class="testslide">
        <div class="item">
          <h3>"I'm an independent artist who needed a way to protect myself and my living. Global Copyrights Protection Bureau for Brands made the process easy and I couldn't be happier with the results!"</h3>
          <p><b>- Alex O.</b>, Boston, MA</p>
        </div>
      </div>
    </div>
  </div>
</section>



<section class="registerwrapper">
  <div class="container">
    <div class="row">
      <div class="registertext">
        <div class="item">
          <p><strong>Intellectual Property Protection – Register a Trademark or Copyright, Apply for a Patent</strong></p>
          <p class="below">Protecting your <strong>intellectual property</strong> is important because it prevents others from capitalizing on your creativity and hard work.&nbsp;Global Copyrights Protection Bureau for Brands can help you with a wide variety of <strong>IP services</strong> to protect your idea, invention, or original work of art.&nbsp;The three main types of intellectual property protection are <strong>trademarks</strong>, <strong>copyrights</strong>, and <strong>patents</strong>. If you are a business owner who is interested in protecting your business name or logo, you may want to apply for trademark registration.&nbsp;Before spending time and money applying to <strong>register a trademark</strong>, a comprehensive trademark search is recommended to determine its availability. A comprehensive <strong>trademark search</strong> looks for any trademarks that may be similar to yours, including those with different spellings. Protection of your books, songs, photographs or other original works of authorship will be enhanced if you register a copyright.&nbsp; <strong>Copyright registration</strong> helps you establish a public record of the copyright claim and allows you to enforce your copyright in federal court. If you want to <strong>patent an idea</strong>, you'll need to start by turning your idea into an actual invention.&nbsp; You may then want to file a provisional application for patent to establish your priority filing date with the <strong>U.S. Patent and Trademark Office (USPTO)</strong> which allows you to immediately start labeling your invention "<strong>patent pending</strong>".&nbsp; Global Copyrights Protection Bureau for Brands can help make the process of applying for a utility patent or design patent easy and affordable.&nbsp; Start protecting your intellectual property by registering a trademark or copyright, filing a patent, or by submitting a provisional patent application online through Global Copyrights Protection Bureau for Brands.&nbsp;    </p>
        </div>
      </div>
    </div>
  </div>
</section>





<?php
$footer = $_SERVER['HTTP_HOST']; 
$footer = "includes/footer.php"; 
include($footer); 
?>




<!-- scroll top car
<div class="car-top"><span>
<img src="assets/images/car.png" alt="Top" title="Back to top" />
</span></div>
-->
</body>
</html>