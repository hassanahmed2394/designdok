<?php
// Initialize the session
session_start();

 
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login.php");
    exit;
}

require_once "webpages/connectiondb.php";

?>


<!doctype html>
<html lang="en">
<head>
<title>Copyright Brand</title>
<meta name="keywords" content="">
<meta name="description" content="">

<?php
$style = $_SERVER['HTTP_HOST']; 
$style = "includes/style.php"; 
include($style); 

$urhere = "homepage";
?>






</head>
<body class="copyrightchecker login paymentchecker">

<?php
$header = $_SERVER['HTTP_HOST']; 
$header = "includes/header.php"; 
include($header); 
?>





<section class="pading-60">
  <div class="container align-self-center">
    <div class="row">
        <div class="steps">
            <h1>Hi, <b><?php echo htmlspecialchars($_SESSION["username"]); ?></b>. Welcome to our site.</h1>
          <h3>Payment Confirmation</h3>
          <div class="formdata_wrapper">
            <div class="databody">
              <div class="datacol-left">
                <form action="webpages/paymentStatusController.php" class="" id="regForm"  method="post">
                  <div class="datadrow inline">
                    <label for="selectcheck">GCPBB Code</label>
                    <select name="gcpbbcode" id="">
                      <?php
                        $sql = mysqli_query($con, "SELECT gcpbb_code From company_registration_tb");
                        $row = mysqli_num_rows($sql);
                        while ($row = mysqli_fetch_array($sql)){
                        echo "<option value='". $row['gcpbb_code'] ."'>" .$row['gcpbb_code'] ."</option>" ;
                        }
                        ?>
                    </select>
                  </div>
                  <div class="datadrow inline">
                    <label for="paymentstatus">Update Payment Status</label>
                    <select name="paymentstatus" id="">
                        <option value="1">Yes</option>
                        <option value="0">No</option>
                    </select> 
                  </div>

                  

                  

                  <div class="datadrow">
                    <input type="submit" value="Update Payment Status">
                  </div>

                </form>

                <a href="logout.php" class="btn btn-danger">Sign Out</a>
              </div>
              
            </div>
          </div>
        </div>
    </div>
  </div>
</section>








<?php
$footer = $_SERVER['HTTP_HOST']; 
$footer = "includes/footer.php"; 
include($footer); 
?>



</body>
</html>