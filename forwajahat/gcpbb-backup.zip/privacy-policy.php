<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Privacy Policy</title>
<?php
$style = $_SERVER['HTTP_HOST']; 
$style = "includes/style.php"; 
include_once($style); 
?>
</head>
<body class="inner-pages policypg">
<?php
$header = $_SERVER['HTTP_HOST']; 
$header = "includes/header.php"; 
include_once($header); 
?>

<section class="sec-padding ">
  <div class="container">
    <div class="row">
      <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 center">
        <h2>Privacy Policy</h2>
        <!-- <ul class="termslist">
          <li><a href="">Disclaimer</a></li>
          <li><a href="">Payment Policy</a></li>
          <li><a href="">Delivery Policy</a></li>
          <li><a href="">Member Area</a></li>
          <li><a href="">Customer Support</a></li>
        </ul> -->
      </div>
    </div>
    <div class="row">
      <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <h4>About GCPBB's Privacy Policy</h4>
        <p>The privacy of our clients is our top priority and we respect it as our own. Though we collect information from our clients, it is only used to make improvements in our customer services. Our company acknowledges that the maintenance and use of our clients' information is our responsibility. We DO NOT rent or sell the information that our clients provide us online. </p>

        
        <h4>Confidentiality of Personal Information</h4>
        <p>The GCPBB operates a strict privacy policy regarding its client information.</p>
        <ul class="pointslist">
          <li>All our customer care agents who deal directly with clients and their personal information are required to sign a confidentiality agreement.</li>
          <li>All client details, registered works or registration details are considered confidential and except where legally required, (i.e. by court order), will not be disclosed to any third party without prior consent.</li>
          <li>Client details will never be passed onto other companies or mailing lists, etc.</li>
          <li>All electronic back ups of works are encrypted, to ensure they cannot be accessed by any unauthorized party.</li>

        </ul>

        <h4>Website Security</h4>
        <p>Confidentiality is a fundamental principal at GCPBB that extends throughout its web site.</p>


        <h4>Secure servers</h4>
        <p>We host our web sites and services using our own secure web and email servers and have in-house IT specialists who manage our systems. This means that your information and files are never stored or copied by any third parties along the way.</p>
        <strong>1.  Registrations and Uploads:</strong>
        <p>When you register or upload a logo design, any files you upload are sent only over a highly encrypted channel that directly connects your computer and our server, and authenticated using a digital certificate.</p>
        <strong>2.  Data entry:</strong>
        <p>We believe the protection of personal data is so important that whenever you access any of the forms on our web site where you may not immediately be concerned about security, you will be redirected to a secure server so that you may enter information without the fear of it being distributed around the internet. This can be verified by the URL starting with 'https:'</p>

        <h4>Secure storage of clients' files</h4>
        <p>When we store your files, it is done in such a way to ensure that it cannot be accessed by any unauthorized person on neither online nor offline mediums. <br><br>Files you upload are immediately obfuscated, and all back up files are encrypted. Our storage servers cannot be directly accessed from the Internet, so they cannot be targeted by hackers.</p>

        <h4>Credit/debit card security </h4>
        <p>We do not store your credit/debit card details on our servers. When you register online using your credit card, we simply pass the details you supply to one of our merchant payment accounts over a 256 bit encrypted channel.</p>
        <h4>Legal Disclaimer</h4>
        <p>We reserve the right to disclose your personally identifiable information as required by law and when we believe that disclosure is necessary to protect our rights and/or comply with a judicial proceeding, court order, or legal process served on our Web site.</p>

        
        

        

        
        
      </div>
    </div>
  </div>
</section>
<?php
$footer = $_SERVER['HTTP_HOST']; 
$footer = "includes/footer.php"; 
include_once($footer); 
?>
</body>
</html>