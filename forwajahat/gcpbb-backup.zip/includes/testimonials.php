<section class="testimonials">
  <div class="container">
    <div class="row">
      <div class="testslide">
        <div class="item">
          <h3>"I'm an independent artist who needed a way to protect myself and my living. Global Copyrights Protection Bureau for Brands made the process easy and I couldn't be happier with the results!"</h3>
          <p><b>- Alex O.</b>, Boston, MA</p>
        </div>
        <!-- <div class="item">
          <h3>"I'm an independent artist who needed a way to protect myself and my living. Global Copyrights Protection Bureau for Brands made the process easy and I couldn't be happier with the results!"</h3>
          <p><b>- Alex O.</b>, Boston, MA</p>
        </div>
        <div class="item">
          <h3>"I'm an independent artist who needed a way to protect myself and my living. Global Copyrights Protection Bureau for Brands made the process easy and I couldn't be happier with the results!"</h3>
          <p><b>- Alex O.</b>, Boston, MA</p>
        </div> -->
      </div>
    </div>
  </div>
</section>
