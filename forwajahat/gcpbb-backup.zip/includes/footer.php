<footer class="footer-main">
  <div class="footer-top">
    <div class="container">
      <div class="row">
        <div class="col-lg-3">
          <a class="xsmtpx-30" href="<?php echo $path;?>">
            <img src="assets/images/logo-footer.png">
          </a>
          <p>An offer of membership in our legal plan is not an endorsement or advertisement for any individual attorney. The legal plan is available in most states.</p>
          
          
        </div>  
        <div class="offset-lg-1 col-lg-3">
          <h3>Services</h3>
          <ul class="linkinglist">
            <li><a href="<?php echo $path;?>services">Our Services</a></li>
            <li><a href="<?php echo $path;?>trademark-registration">Trademark registration</a></li>
            <li><a href="<?php echo $path;?>copyright-registration">Copyright registration</a></li>
            <li><a href="brand-patent">patent your brand</a></li>
          </ul>
        </div>
        <div class="col-lg-3">
          <h3 class="xsmtpx-30">Quick Links</h3>
          <ul class="linkinglist">
            <li><a href="<?php echo $path;?>">Home</a></li>
            <!-- <li><a href="culture">Culture</a></li> -->
            <li><a href="<?php echo $path;?>why-us">Why Us</a></li>
            <li><a href="<?php echo $path;?>copyrightchecker">Copyrightchecker</a></li>
          </ul>
        </div>
        <div class="col-lg-2">
          <h3 class="xshide">Contact Info</h3>
          <ul class="linkinglist">
            <li><a href="<?php echo $numberlink;?>"><?php echo $number;?> </a></li>
            <li><a href="<?php echo $emaillink;?>"><?php echo $email;?> </a></li>
            <li><a href="javascript:;" onclick="setButtonURL();" target="_self">Live Chat</a></li>
          </ul>
        </div>
        
      </div>
      <div class="row">
        <div class="col-lg-12">
          <div class="socialmid">
            
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="footer-bottom">
    <div class="container">
      <div class="row">
        <div class="col-sm-9">
          <p class="copyright">An offer of membership in our legal plan is not an endorsement or advertisement for any individual attorney. The legal plan is available in most states.</p>
          <p class="copyright">&copy;  Global Copyrights <span id="year"></span>. All rights reserved.</p>
          <p class="disclaimer">Disclaimer: Communications between you and Global Copyrights Protection Bureau for Brands are protected by our <a href="<?php echo $path;?>privacy-policy" target="_blank" id="ftrPrvPol">Privacy Policy</a> but not by the attorney-client privilege or as work product. Global Copyrights Protection Bureau for Brands provides access to independent attorneys and self-help services at your specific direction. We are not a law firm or a substitute for an attorney or law firm. We cannot provide any kind of advice, explanation, opinion, or recommendation about possible legal rights, remedies, defenses, options, selection of forms or strategies. Your access to the website is subject to our <a href="<?php echo $path;?>terms-and-conditions" target="_blank" id="ftrToU">Terms of Use</a>.</p>
        </div>
        
        <div class="col-sm-3">
          <ul class="footer-nav2">
            <li><a href="javascript:;" title=""><img src="assets/images/getseal.gif"></a></li>
            <li><a href="javascript:;" title=""><img src="assets/images/getseal2.png"></a></li>
            <!-- <li>
              <ul class="linkinglist followus">
                <li><a href="javascript:;"><i class="icon-facebook-square"></i></a></li>
                <li><a href="javascript:;"><i class="icon-twitter"></i></a></li>
                <li><a href="javascript:;"><i class="icon-google-plus-square"></i></a></li>
                <li><a href="javascript:;"><i class="icon-linkedin-square"></i></a></li>
              </ul>
            </li> -->
          </ul>
        </div>
      </div>
    </div>
  </div>
  <!-- <div class="disclaimer-area">
    <div class="container">
      <div class="row">
        <div class="col">
          <p class="disclaimer"><strong>Disclaimer:</strong><br>
            The services provided by Ghost Writers become clients' property once delivered. Ghost Writers will not hold any ownership rights once your work is successfully accepted by a publishing house.</p>
        </div>
      </div>
    </div>
  </div> -->
</footer>
</main>


<script src="assets/js/mlib.js"></script> 
<script src="assets/js/functions.js"></script> 

<!-- Start of  Zendesk Widget script -->
<!-- <script id="ze-snippet" src="https://static.zdassets.com/ekr/snippet.js?key=2d641d22-dd16-45bd-a152-1f557bc3b7c9"> 
function setButtonURL(){
    
    $zopim.livechat.window.toggle();
    
}

</script> -->
<!-- End of  Zendesk Widget script -->