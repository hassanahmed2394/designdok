<?php


$brandname = "Bravo";
$numberlink = "tel:+441442902191";
$number = "+44-144-290-2191 ";
$email = "support@gcpbb.co.uk";
$emaillink = "mailto:support@gcpbb.co.uk";

?>