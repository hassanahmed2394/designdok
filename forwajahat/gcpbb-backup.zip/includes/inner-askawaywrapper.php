<section class="askawaywrapper">
  <div class="container">
    <div class="row">
      <div class="topwrapper">
        <h2>Ask away. We have answers.</h2>
      </div>
      <div class="askaway">
        <div class="item col4">
          <h3>Common questions</h3>
          <div class="accordion">
            <div class="quest-section"> <a class="quest-title" href="#accordion-1">What are the rights of a copyright owner?</a>
              <div id="accordion-1" class="quest-content">
                <p>The owner of a copyright has the exclusive right to reproduce, distribute copies (for sale or otherwise), publicly perform or display, or create derivative works of the copyrighted work.They also have the right to authorize others to do the same.</p>
              </div>
            </div>
            <div class="quest-section"> <a class="quest-title" href="#accordion-2">How long does a design patent last?</a>
              <div id="accordion-2" class="quest-content">
                <p>The term of a design patent is 14 years, beginning on the date the patent is granted. This is in contrast to a utility patent term, which typically lasts 20 years and is measured from the application priority filing date. Design patents are not renewable and require no maintenance fees. </p>
              </div>
            </div>
            <div class="quest-section"> <a class="quest-title" href="#accordion-3">How long will it take to prepare my design patent application?</a>
              <div id="accordion-3" class="quest-content">
                <p>The process of preparing the application and technical drawings generally takes 2-3 weeks. Once the application is filed, you may legally label your design "patent pending" for the period that your application is awaiting approval.</p>
              </div>
            </div>
            <div class="quest-section"> <a class="quest-title" href="#accordion-4">What's the difference between a copyright and a trademark?</a>
              <div id="accordion-4" class="quest-content">
                <p>Copyrights generally protect artistic works, such as songs, paintings, books, and audiovisual works. Trademarks are generally used to protect brand names, slogans, and logos for businesses.</p>
              </div>
            </div>

            <div class="quest-section"> <a class="quest-title" href="#accordion-5">What works are protected by copyright?</a>
              <div id="accordion-5" class="quest-content">
                <p>Copyright protects "original works of authorship" that are fixed in a tangible form including the following: Literary works Musical works, including any accompanying words Dramatic works, including any accompanying music Pantomimes and choreographic works Pictorial, graphic and sculptural works Motion pictures and other audiovisual works Sound recordings Architectural works These categories should be viewed broadly. For example, computer code and many "compilations" may be registered as "literary works." Maps and architectural plans may be registered as "pictorial, graphic and sculptural works."</p>
              </div>
            </div>
            
          </div>
        </div>

        <div class="item col4">
          <h3>A specialist is here to help</h3>
          <div class="miditem">
            <figcaption>
              <img src="assets/images/girl2.png">
            </figcaption>  
            <h4 class="callnumber">+44-144-290-2191</h4>
            <p>We're available <b>Mon-Fri 5am-7pm PT ,</b><br><b> Weekends 7am-4pm PT</b></p>
            <!-- <div class="midbotm"><img src="assets/images/american-flag.png"><p>Our agents are based in the United States.</p></div> -->
          </div>
        </div>

        <div class="item col4">
          <h3>A specialist is here to help</h3>
          <div class="miditem">
            <figcaption>
              <img src="assets/images/male.png">
            </figcaption>  
            <p class="lastitem-p">Get legal advice from an independent attorney at a price you can afford.</p>
            <a href="javascript:;" onclick="setButtonURL();">Find out more</a>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>