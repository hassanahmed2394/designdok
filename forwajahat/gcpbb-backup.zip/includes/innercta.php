<section class="innercta">
  <div class="container">
    <div class="row">
      <div class="col-lg-12">
        <div class="formwrap">
          <div class="textwrapper">
            <h3>Get helpful tips and info from our newsletter!</h3>
          </div>
          <div class="subscribeform">
            <form class="" id="banform"  method="POST" action="webpages/bannerFormController.php">
              
                <div class="wrap">
                  <div class="dtf">
                    <input id="fname" name="Search" minlength="5" class="round" type="text" placeholder="Your Email Address" required />
                  </div>
                  
                  <div class="dtf btnpart text-left">
                    <input class="submit" type="submit" value="Submit" />
                  </div>
                </div>

              
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>