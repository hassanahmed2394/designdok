<section class="getstartedwapper"  style="background-image:url(assets/images/banners/patents-bg.jpg)">
  <div class="container">
    <div class="row">
      <!-- <div class="col-lg-6">
        <div class="topwrapper">
          <h2>Get started today</h2>
          <p>Completion of provisional application for patent. Digitizing and color adjustment of your technical drawings Professional review (optional), which includes drafting one independent claim and more. Completion of provisional application for patent. Digitizing and color adjustment of your technical drawings Professional review (optional), which includes drafting one independent claim and more Completion of provisional application for patent. Digitizing and color adjustment of your technical drawings Professional review (optional), which includes drafting one independent claim and more drafting one independent claim and more.</p>
          <div class="btnwrapper">
            <a href="javascript:;" onclick="setButtonURL();" class="btn-theme">Live Chat</a>
            <a href="tel:+441442902191" class="btn-outline">+44-144-290-2191 </a>
          </div>

        </div>
      </div> -->
      <div class="col-lg-6 offset-lg-3">
        <div class="getboxwrapper">
          <div class="item">
            <h4>Provisional Patent Application</h4>
            <h3><span>£</span>299.00</h3>
            <h6>+ filing fee</h6>
            <h5>Includes:</h5>
            <ul class="packlist">
              <li>Completion of provisional application for patent</li>
              <li>Digitizing and color adjustment of your technical drawings</li>
              <li>Professional review (optional), which includes drafting one independent claim and more</li>
            </ul>
            <!-- <a href="javascript:;">View More</a> -->
            <a href="<?php echo $path;?>get-a-quote" class="start">Start my application</a>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>