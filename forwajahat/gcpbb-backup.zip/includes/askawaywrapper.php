<section class="askawaywrapper">
  <div class="container">
    <div class="row">
      <div class="topwrapper">
        <h2>Ask away. We have answers.</h2>
      </div>
      <div class="askaway">
        <div class="item col4">
          <h3>Common questions</h3>
          <div class="accordion">
            <div class="quest-section"> <a class="quest-title" href="#accordion-1">What's the difference between a copyright and a trademark?</a>
              <div id="accordion-1" class="quest-content">
                <p>Copyrights generally protect original creative works, such as books, movies, songs, paintings, photographs, web content, and choreography. Trademarks, on the other hand, generally protect brand names, slogans, and logos that are used in the marketplace, and help consumers distinguish among products.</p>
              </div>
            </div>
            <div class="quest-section"> <a class="quest-title" href="#accordion-2">What works are eligible for copyright protection?</a>
              <div id="accordion-2" class="quest-content">
                <p>Copyright protects "original works of authorship" that are fixed in a tangible form. Broadly, this includes literary works, musical works, dramatic works, pantomimes and choreographic works, pictorial, graphic and sculptural works, motion pictures and other audiovisual works, sound recordings and architectural works</p>
              </div>
            </div>
            <div class="quest-section"> <a class="quest-title" href="#accordion-3">What are the benefits of a registered trademark?</a>
              <div id="accordion-3" class="quest-content">
                <p>Some trademark rights are established simply by using the mark. However, these rights are limited and generally apply only to a limited geographical area. Registering for a federal trademark greatly expands your rights, and allows you to bring a federal suit against others who may be infringing on your trademark.</p>
              </div>
            </div>
            <div class="quest-section"> <a class="quest-title" href="#accordion-4">What's the difference between a design patent and a utility patent?</a>
              <div id="accordion-4" class="quest-content">
                <p>A design patent protects the unique appearance of a manufactured item–how it looks–and a utility patent protects an item's function–how it works. A utility patent may also be granted to protect a unique process or chemical compound. Some inventions may qualify for both design and utility patent protection, if both the design and the function are unique, and the design does not affect the article's function.</p>
              </div>
            </div>
            
          </div>
        </div>

        <div class="item col4">
          <h3>A specialist is here to help</h3>
          <div class="miditem">
            <figcaption>
              <img src="assets/images/girl2.png">
            </figcaption>  
            <h4 class="callnumber">+44-144-290-2191</h4>
            <p>We're available <b>Mon-Fri 5am-7pm PT ,</b><br><b> Weekends 7am-4pm PT</b></p>
            <!-- <div class="midbotm"><img src="assets/images/american-flag.png"><p>Our agents are based in the United States.</p></div> -->
          </div>
        </div>

        <div class="item col4">
          <h3>A specialist is here to help</h3>
          <div class="miditem">
            <figcaption>
              <img src="assets/images/male.png">
            </figcaption>  
            <p class="lastitem-p">Get legal advice from an independent attorney at a price you can afford.</p>
            <a href="javascript:;">Find out more</a>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>