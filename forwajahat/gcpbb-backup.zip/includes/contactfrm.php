<form action="webpages/contactFormController.php" class="" id="regForm"  method="post" enctype="multipart/form-data">
  <div class="">
    <div class="steps">
    <h3>Personal information</h3>
   
    <div style="" class="stepset">
      <span class="step"> Step 01</span>
    </div>

      <div class="inputfield">
        <label for="Name">Enter Your Name *</label>
        <input type="text" name="Name" class="required alphanumeric cname" required />
      </div>
      <div class="inputfield">
        <label for="Email">Enter Your Email *</label>
        <input type="email" name="Email" class="required email cemail"/>
      </div>
      
      <div class="inputfield">
        <div class="numberarea">
          <label for="Number">Enter Your Number *</label>
          <input type="number" name="Number" class="required number cphone" pattern="[0-9]*" />
        </div>
      </div>
    </div>







<!-- 2nd step -->
    <div class="steps">
    <h3>Design Specifications</h3>
                  <p>Design Specifications Design Specifications Design Specifications Design Specifications </p>
                  <div style="" class="stepset">
      <span class="step"> Step 02</span>
    </div>
      <div class="inputfield">
        <label for="cname">Your Company's Name *</label>
        <input type="text" name="Companyname" class="required" oninput="this.className = ''"/>
      </div>

      <div class="inputfield">
        <label for="industry">Industry *</label>
        <input type="text" name="Industry" class="required" oninput="this.className = ''"/>
      </div>

      <div class="inputfield">
        <label for="dcname">Design Company's Name *</label>
        <input type="text" name="DesignCompanyName" class="required" oninput="this.className = ''"/>
      </div>

      <div class="inputfield">
        <label for="titledesign">Title of Your design *</label>
        <input type="text" name="Titledesign" class="required" oninput="this.className = ''"/>
      </div>

      <div class="inputfield">
        <label for="Caption">Caption</label>
        <input type="text" name="Caption" oninput="this.className = ''"/>
      </div>

      

      <div class="inputfield">
        <label for="unique">Unique features of your logo design</label>
        <input type="text" name="UniqueFeatures" oninput="this.className = ''"/>
      </div>


      <div class="inputfield">
        <label class="field-txt">Upload your Logo Design (in color and gray scale)<span>*</span></label>
        <input type="file" name="wordfile" id="fileToUpload">
      </div>
    </div>

      
<!-- 3rd Step -->

    <div class="steps">
    <h3>Communication Details</h3>
    <p>Communication Details Communication Details Communication Details Communication Details </p>
    <div style="" class="stepset">
      <span class="step"> Step 03</span>
    </div>
      <div class="inputfield">
        <label for="Preffered_medium_one">Indicate your 1st preferred medium of communication for communicating with us *</label>
        <select name="Preffered_medium_one" class="required" aria-invalid="false" oninput="this.className = ''" >
          <option  value=""> Select your 1st preference</option>
            <option  value="Phone">Phone</option>
            <option  value="Chat">Chat</option>
            <option  value="Email">Email</option>
            <option  value="SMS">SMS</option>
        </select>
      </div>



      <div class="inputfield">
        <label for="Preffered_medium_two">Indicate your 2nd preferred medium of communication for communicating with us</label>
        <select name="Preffered_medium_two" class="required" aria-invalid="false" oninput="this.className = ''" >
          <option  value=""> Select your 2nd preference</option>
            <option  value="Phone">Phone</option>
            <option  value="Chat">Chat</option>
            <option  value="Email">Email</option>
            <option  value="SMS">SMS</option>
        </select>
      </div>

    </div>




<!-- 4th Step -->
    <div class="steps">
    <h3>Prefer Time to Call</h3>
    <p>Prefer Time to Call Prefer Time to Call Prefer Time to Call Prefer Time to Call </p>
    <div style="" class="stepset">
      <span class="step"> Step 04</span>
    </div>
      <div class="inputfield">
        <label for="datetime">Time - From To</label>
        <input type="datetime-local" id="meeting-time" name="Meeting_time" value="2019-06-12T19:30" >
      </div>



      
      <div class="check-list inputfield terms">
        <input  type="checkbox" name="Termscheck" value="No" >
        <label for="termscheck">Click to accept  <a href="javascript:;">terms and conditions</a></label>
      </div>



    </div>

<div class="inputfield btns">
      
      
      <input type="hidden" name="hiddencapcha" value="">
      <button type="button" id="prevBtn" onclick="nextPrev(-1)">Previous</button>
    <button type="button" id="nextBtn" onclick="nextPrev(1)">Next</button>
      
    </div>

<!-- 5th step -->


<!-- <div class="steps laststep">

   <div class="formdata_wrapper">
    <div class="datahead">
      <h3>Personal Details</h3>

      
    </div>
    <div class="databody">
      <div class="datacol-left">
        <div class="datadrow">
          <div class="datadfields">
            <h4>Your Name</h4>
          </div>
          <div class="datadcolected">
            <h5>Desi</h5>
          </div>
        </div>

        <div class="datadrow">
          <div class="datadfields">
            <h4>Your Email</h4>
          </div>
          <div class="datadcolected">
            <h5>Desi</h5>
          </div>
        </div>
      </div>
      
    </div>
  </div> 


  <div class="formdata_wrapper">
    <div class="datahead">
      <h3>Design Specifications</h3>
      
    </div>
    <div class="databody">
      <div class="datacol-left">
        <div class="datadrow">
          <div class="datadfields">
            <h4>Your Company's Name</h4>
          </div>
          <div class="datadcolected">
            <h5>Desi</h5>
          </div>
        </div>

        <div class="datadrow">
          <div class="datadfields">
            <h4>Industry</h4>
          </div>
          <div class="datadcolected">
            <h5>Desi</h5>
          </div>
        </div>

        <div class="datadrow">
          <div class="datadfields">
            <h4>Design Company's Name:</h4>
          </div>
          <div class="datadcolected">
            <h5>Desi</h5>
          </div>
        </div>

        <div class="datadrow">
          <div class="datadfields">
            <h4>Title of Your design</h4>
          </div>
          <div class="datadcolected">
            <h5>Desi</h5>
          </div>
        </div>

        <div class="datadrow">
          <div class="datadfields">
            <h4>Caption (If Any)</h4>
          </div>
          <div class="datadcolected">
            <h5>Desi</h5>
          </div>
        </div>

        <div class="datadrow">
          <div class="datadfields">
            <h4>Unique features of your logo design:</h4>
          </div>
          <div class="datadcolected">
            <h5>Desi</h5>
          </div>
        </div>

        
      </div>
      
    </div>
  </div>



   <div class="formdata_wrapper">
    <div class="datahead">
      <h3>Preffered Language</h3>
     
    </div>
    <div class="databody">
      <div class="datacol-left">
        <div class="datadrow">
          <div class="datadfields">
            <h4>Indicate your 1st preferred medium of communication</h4>
          </div>
          <div class="datadcolected">
            <h5>Desi</h5>
          </div>
        </div>

        <div class="datadrow">
          <div class="datadfields">
            <h4>Indicate your 2nd preferred medium of communication</h4>
          </div>
          <div class="datadcolected">
            <h5>Desi</h5>
          </div>
        </div>
      </div>
      
    </div>
  </div> 

</div> -->
  




    
    
    

    
  </div>
</form>

