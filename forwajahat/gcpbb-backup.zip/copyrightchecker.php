<!doctype html>
<html lang="en">
<head>
<title>Start a Business, Protect Your Brand, Trademark Incorporate & More Online | gcpbb.co.uk | Global Copyrights Protection Bureau for Brands</title>
<meta name="keywords" content="">
<meta name="description" content="">

<?php
$style = $_SERVER['HTTP_HOST']; 
$style = "includes/style.php"; 
include($style); 

$urhere = "copyrightchecker";
?>






</head>
<body class="copyrightchecker">

<?php
$header = $_SERVER['HTTP_HOST']; 
$header = "includes/header.php"; 
include($header); 
?>



<!-- <section class="innerbanner  d-flex" style="background-image:url(assets/images/banners/innerpgbanner.jpg)">
  <div class="container align-self-center">
    <div class="row">
      <div class="col-lg-12">
        <div class="text-wrap">
          <h5>Intellectual Property</h5>
          <h1>Make sure your work is protected</h1>
          <p>Whether you need a copyright, trademark or patent, we can help make the process easy and affordable.</p>
        </div>
      </div>
    </div>
  </div>
</section> -->


<?php

 $name = "........";
  $company = "........";
  $gcpbb_code_db = "........";
  $title = "........";
  $caption = "........";
  $uniquefeatures = "........";
  $logosrc = "https://gcpbb.co.uk/assets/images/samplelogo.png";
  $statusmessage = "";

// check if the form has been submitted and display the results
if (isset($_POST['Search'])) {

 include("webpages/connectiondb.php");

  // escape the post data to prevent injection attacks
  $gcpbbcode = mysqli_real_escape_string($con, $_POST['Search']);
  

  $sql = "SELECT name,companyname,gcpbb_code,Titledesign,Caption,UniqueFeatures,uploaded_file_URL,paymentStatus FROM `company_registration_tb` WHERE `gcpbb_code` LIKE '%$gcpbbcode%' and `paymentStatus` = '1'"; 
  
  
  
  
  
  
  
  
  $result=mysqli_query($con,$sql);

  
  
  
  
  if(mysqli_num_rows($result) > 0) {
      //print_r($result);
      while($row = mysqli_fetch_array($result, MYSQLI_ASSOC))
        {
          
          $name = $row['name'];
          $company = $row['companyname'];
          $gcpbb_code_db = $row['gcpbb_code'];
          $title = $row['Titledesign'];
          $caption = $row['Caption'];
          $uniquefeatures = $row['UniqueFeatures'];
          $logosrc = $row['uploaded_file_URL'];
          $statusmessage = "Verifying your details against our pre-specified criteria";
          
        }
      
      
  } else {
    
    //echo 'There are no results for your search';
    $statusmessage = "Sorry! You are not in our list";
    
  }
mysqli_close($con);  
  
} // end submitted
else
{
 $name = "........";
  $company = "........";
  $gcpbb_code_db = "........";
  $title = "........";
  $caption = "........";
  $uniquefeatures = "........";
  $logosrc = "https://gcpbb.co.uk/assets/images/samplelogo.png";
  $statusmessage = "";
}
?>

<section class="pading-60">
  <div class="container align-self-center">
    <div class="row">
      <div class="col-lg-8 offset-lg-2">
        <div class="copyright-gifwrapper">
          <figure><img src="assets/images/HeaderRocketDesktop.svg" alt=""></figure>
          <h3>Over <strong>1 million LLCs</strong> launched</h3>
          <p>We're the Copyright Productionsexperts - with us it's fast, easy, affordable and done right. <br> See if your chosen company name is available by searching below. Let’s do this!</p>
          <div class="analyzeform searchbar">
            <form class="" id="banform"  method="POST" action="copyrightchecker.php">
              
                <div class="wrap">
                  <div class="dtf">
                    <input id="fname" name="Search" minlength="5" class="round" type="text" placeholder="Enter Your Brand Name" required />
                  </div>
                  
                  <div class="dtf btnpart text-left">
                    <input class="submit" type="submit" value="Search" />
                  </div>
                </div>

              
            </form>
          </div>
        </div>
      </div>
      <div class="col-lg-6 offset-lg-3">
        <div class="steps laststep" style="padding-top:0px;">
          <!-- <h3>Copyright Checker</h3> -->


          <div class="formdata_wrapper ">
            <div class="datahead">
              <h4>Status: <span><?php echo $statusmessage ?></span></h4>
            </div>
            <div class="databody">
              <div class="datacol-left">
                
                <div class="datadrow">
                  <div class="datadfields">
                    <h4>Your Name:</h4>
                  </div>
                  <div class="datadcolected">
                    <h5><?php echo $name ?></h5>
                  </div>
                </div>

                <div class="datadrow">
                  <div class="datadfields">
                    <h4>Company:</h4>
                  </div>
                  <div class="datadcolected">
                    <h5><?php echo $company ?></h5>
                  </div>
                </div>

                <div class="datadrow">
                  <div class="datadfields">
                    <h4>GCPBB Code:</h4>
                  </div>
                  <div class="datadcolected">
                    <h5><?php echo $gcpbb_code_db ?></h5>
                  </div>
                </div>

                <div class="datadrow">
                  <div class="datadfields">
                    <h4>Title:  </h4>
                  </div>
                  <div class="datadcolected">
                    <h5><?php echo $title ?></h5>
                  </div>
                </div>

                <div class="datadrow">
                  <div class="datadfields">
                    <h4>Caption:</h4>
                  </div>
                  <div class="datadcolected">
                    <h5><?php echo $caption ?></h5>
                  </div>
                </div>

                <div class="datadrow">
                  <div class="datadfields">
                    <h4>Unique Feature:</h4>
                  </div>
                  <div class="datadcolected">
                    <h5><?php echo $uniquefeatures ?></h5>
                  </div>
                </div>
                <div class="datadrow">
                  <div class="datadfields">
                    <h4>Your Logo:</h4>
                  </div>
                  <div class="datadcolected">
                    <img src="<?php echo $logosrc ?>">
                  </div>
                </div>

                
              </div>
              
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<?php

?>


<?php
$footer = $_SERVER['HTTP_HOST']; 
$footer = "includes/footer.php"; 
include($footer); 
?>



</body>
</html>