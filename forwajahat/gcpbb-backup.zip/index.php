<!doctype html>
<html lang="en">
<head>
<title>Start a Business, Protect Your Brand, Trademark Incorporate & More Online | gcpbb.co.uk | Global Copyrights Protection Bureau for Brands</title>
<meta name="keywords" content="">
<meta name="description" content="">

<?php
$style = $_SERVER['HTTP_HOST']; 
$style = "includes/style.php"; 
include($style); 

$urhere = "homepage";
?>






</head>
<body class="hompg">

<?php
$header = $_SERVER['HTTP_HOST']; 
$header = "includes/header.php"; 
include($header); 
?>





<div class="slider-wrapper">
  <section class="">
    <div class="item">
      <div class="home-banner"  style="">
        <div class="bg1" id="h-bg">
          <div class="container">
            <div class="row">
              <div class=" col-lg-12">
                <div class="bannernav">
                  <div class="wrap">
                    <!-- <ul class="mainservices">
                      <li><a href="javascript:;">Secure Brand</a></li>
                      <li><a href="javascript:;">Protect Your Logo & Website</a></li>
                      <li><a href="javascript:;">Copyright Infringement</a></li>
                      <li><a href="javascript:;">Get Help from Attorney</a></li>
                    </ul> -->
                    <ul class="nav nav-tabs mainservices">
                      <li class="active"><a data-toggle="tab" href="#hometab" id="hometabone">Secure Brand</a></li>
                      <li><a data-toggle="tab" href="#hometab2" id="hometabtwo">Protect Your Logo & Website</a></li>
                      <li><a data-toggle="tab" href="#hometab3" id="hometabthree">Copyright Infringement</a></li>
                      <li><a data-toggle="tab" href="#hometab4" id="hometabfour">Get Help from Attorney</a></li>
                    </ul>
                    <ul class="otherservices">
                      <li><a href="<?php echo $path;?>trademark-registration">Trademark Registration</a></li>
                      <li><a href="<?php echo $path;?>copyright-registration">Copyright registration</a></li>
                      <li><a href="<?php echo $path;?>brand-patent">Patent Your Brand</a></li>
                    </ul>
                  </div>
                </div>
                <div class="tab-content">
                  <div id="hometab" class="tab-pane active">
                    <div class="home-banner-content">
                      <h1>Secure Brand</h1>
                      <p>Brand name protection helps startups and mid sized companies.</p>
                      <a href="<?php echo $path;?>get-a-quote" class="btn-theme">Get Secure</a>
                    </div>
                  </div>
                  <div id="hometab2" class="tab-pane fade">
                    <div class="home-banner-content">
                      <h1>Protect your logo and Website</h1>
                      <p>You have worked hard to design or build a name for your business. </p>
                      <a href="<?php echo $path;?>get-a-quote" class="btn-theme">Get Secure</a>
                    </div>
                  </div>
                  <div id="hometab3" class="tab-pane fade">
                    <div class="home-banner-content">
                      <h1>Copyright Infringement </h1>
                      <p>Registering your copyright greatly enhances your legal protections against infringement.</p>
                      <a href="<?php echo $path;?>get-a-quote" class="btn-theme">Get Secure</a>
                    </div>
                  </div>
                  <div id="hometab4" class="tab-pane fade">
                    <div class="home-banner-content">
                      <h1>Brandname Help for Businesses and Families all over the world</h1>
                      <p>We've helped over 2 million people get the help they need</p>
                      <a href="<?php echo $path;?>get-a-quote" class="btn-theme">Get Secure</a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    
  </section>
  
</div>



<section class="recognitionsec">
  <div class="container">
    <div class="row">
      <figure>
        <img src="assets/images/recognition.png">
      </figure>
    </div>
  </div>
</section>


<section class="boxessec">
  <div class="container">
    <div class="row">
      <div class="col-lg-12">
        <div class="boxeswrap">
          <h2>Make sure your brand is protected</h2>
          <p>Whether you need a copyright, trademark or patent, we can help make the process easy and affordable </p>
          <ul>
            <li>
              <div class="textwrap">
                <h3>For Free Consultancy Regarding Brand Copyrights and Protection. Many people finish in under 10minutes. </h3>
                
                <a href="javascript:;" class="btn-theme">Start My Application </a>
              </div>
              <figure class="left-mostconsultancy">
                <img src="assets/images/girl-a.png">
              </figure>
            </li>
            <li class="centerbox">
              <div class="textwrap">
                <h3>Not sure which type of protection you need?</h3>
                <p>FREE Copyright Brand Consultancy.</p>
                <a href="javascript:;" onclick="setButtonURL();" class="btn-theme">Let us guide you</a>
              </div>
              <figure>
                <img src="assets/images/girl2.png">
              </figure>
            </li>
            <li>
              <div class="textwrap">
                <ul class="boxlist">
                  <li>Trusted by thousands of international organizations and creative individuals.</li>
                  <li>Global alliances and partnerships.</li>
                  <li>100% Brand Copyright Guarantee.</li>
                </ul>
                
                <a href="javascript:;" class="btn-theme">Start My Application </a>
              </div>
              <figure class="right-mostconsultancy">
                <img src="assets/images/guarantee.png">
                
              </figure>
            </li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</section>

<section class="helpsec">
  <div class="container">
    <div class="row">
      <div class="col-lg-4">
        <div class="imgplace">
          <figure>
            <img src="assets/images/HeaderRocketDesktop.svg">
          </figure>
        </div>
      </div>
      <div class="col-lg-8">
        <div class="txtwrap">
          <h2>Secure your brand</h2>
          <p>We're in the business of providing clarity—whether you use our simplified self-guided legal services or work with one of our fantastic independent attorneys, or both, we've got your back.
          </p>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="wayswrapper ">
        <ul>
          <li>
            <h3>Make your business official </h3>
            <p>GCPBB provides intellectual property rights for brands by guarding their logo designs. We secure you creative expressions by authenticating your logo design and providing you with .</p>
          </li>
          
          <li>
            <h3>&nbsp;</h3>
            <p>We proudly operates to ensure absolute protection of copyrights to our customers. We have been providing logo copyrights, globally, for the past 10 years through offline mediums.</p>
          </li>
          <li>
            <h3>&nbsp; </h3>
            <p>We provides intellectual property rights for brands by guarding their logo designs. We secure you creative expressions by authenticating your logo design and providing you with .</p>
          </li>
          
        </ul>
      </div>
    </div>
    <div class="row">
      <div class="col-lg-12 ctabottom">
        <h3>For free consultancy regarding <strong>Brand Copyrights</strong> <span>Protect your creative expression. Give us a call <a href="tel:+441442902191 ">+44-144-290-2191 </a></span></h3> 
        <a href="https://gcpbb.co.uk/get-a-quote" class="btn-theme">Start My Application </a>
        
      </div>
    </div>
  </div>
</section>



<section class="reasonssec">
  <div class="container">
    <div class="row">
      <div class="col-lg-12">
        <h2>Reasons to form Copyright Productions today</h2>
        <p>Starting a business can literally change your life.</p>
        <div class="wrap">
          <ul>
            <li>
              <div class="iconwrap">
                <i class="smiley"></i>
              </div>
              <h3>Freedom</h3>
              <p>Perfect for people already running a business as well as new businesses.</p>

            </li>
            <li>
              <div class="iconwrap">
                <i class="time"></i>
              </div>
              <h3>Seize the day</h3>
              <p>Often taking the first step is the hardest. File the Copyright Productionsand go from there as suits you.</p>

            </li>
            <li>
              <div class="iconwrap">
                <i class="house"></i>
              </div>
              <h3>Protection</h3>
              <p>An Copyright Productionsprotects you and your family by separating your personal and business assets.</p>

            </li>
            <li>
              <div class="iconwrap">
                <i class="secure"></i>
              </div>
              <h3>Liability</h3>
              <p>Helps ensure you're not personally liable for mistakes your business might make.</p>

            </li>
            <li>
              <div class="iconwrap">
                <i class="tick"></i>
              </div>
              <h3>Practical</h3>
              <p>Perfect for people already running a business as well as new businesses.</p>

            </li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</section>


<!-- <section class="searchformsec">
  <div class="container">
    <div class="row">
      <div class="col-lg-12">
        <h3>See if your Brand name is available now</h3>
        <div class="wrap">
           <div class="analyzeform">
              <form class="" id="banform"  method="POST" action="webpages/bannerFormController.php">
                <div class="row">
                  <div class="wrap">
                    <div class="dtf">
                      <input id="fname" name="Search" minlength="5" class="round" type="text" placeholder="Enter Your Brand Name" required />
                    </div>
                    
                    <div class="dtf btnpart text-left">
                      <input class="submit" type="submit" value="Search" />
                    </div>
                  </div>

                </div>
              </form>
            </div>
          </div>
      </div>
    </div>
  </div>
</section> -->


<section class="strugglesec">
  <div class="container">
    <div class="row">
      <div class="col-lg-4">
        <div class="paright">
          <h2>Why Choose GCPBB?</h2>
          <p>There can be a number of reasons making hurdles between you and your dream.</p>
        </div>
      </div>      


      <div class="col-lg-8">
        <ul>

          <li>There can be a number of reasons making hurdles between you and your dream.</li>
          <li>Certified body to protect your logo design from infringement.</li>
          <li>Global alliances and partnerships.</li>
          <li>100% Brand Copyright Guarantee. </li>
          <li>FREE Copyright Brand Consultancy.</li>
          
          
          <li>The Copyright Registration process is quick, low cost and hassle-free.</li>

        </ul>
        <div class="">
          <a href="https://gcpbb.co.uk/get-a-quote" class="btn-theme">Let’s Get Started </a>
        </div>
      </div>
    </div>
  </div>
</section>






<?php
$footer = $_SERVER['HTTP_HOST']; 
$footer = "includes/footer.php"; 
include($footer); 
?>



</body>
</html>