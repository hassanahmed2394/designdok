<?php
// Initialize the session
session_start();
 
// Check if the user is already logged in, if yes then redirect him to welcome page
if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true){
    header("location: payment-confirmation.php");
    exit;
}
 
// Include config file
require_once "webpages/connectiondb.php";
//include("webpages/connectiondb.php");
 
// Define variables and initialize with empty values
$username = $password = "";
$username_err = $password_err = "";

// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){
 
    // Check if username is empty
    if(empty(trim($_POST["username"]))){
        $username_err = "Please enter username.";
    } else{
        $username = trim($_POST["username"]);
    }
    
    // Check if password is empty
    if(empty(trim($_POST["password"]))){
        $password_err = "Please enter your password.";
    } else{
        $password = trim($_POST["password"]);
    }
    
    // Validate credentials
    if(empty($username_err) && empty($password_err)){
        // Prepare a select statement
        $sql = "SELECT id, username, password FROM `users` WHERE `username` = ?";
        
        
        if($stmt = mysqli_prepare($con, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "s", $param_username );
            
            // Set parameters
            $param_username = $username;
            
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                // Store result
                mysqli_stmt_store_result($stmt);
                
                // Check if username exists, if yes then verify password
                if(mysqli_stmt_num_rows($stmt) == 1){                    
                    // Bind result variables
                    mysqli_stmt_bind_result($stmt, $id, $username, $parampassword);
                    
                    if(mysqli_stmt_fetch($stmt)){
                        if($password == $parampassword){
                            // Password is correct, so start a new session
                            session_start();
                            
                            // Store data in session variables
                            $_SESSION["loggedin"] = true;
                            $_SESSION["id"] = $id;
                            $_SESSION["username"] = $username;                            
                            
                            // Redirect user to welcome page
                            header("location: payment-confirmation.php");
                        } else{
                            // print_r($parampassword);
                            // print_r($password);
                            // Display an error message if password is not valid
                            $password_err = "The password you entered was not valid.";
                        }
                    }
                } else{
                    // Display an error message if username doesn't exist
                    $username_err = "No account found with that username.";
                }
            } else{
                echo "Oops! Something went wrong. Please try again later.";
            }
        }
        
        // Close statement
        mysqli_stmt_close($stmt);
    }
    
    // Close connection
    mysqli_close($con);
}
?>
<!doctype html>
<html lang="en">
<head>
<title>Copyright Brand</title>
<meta name="keywords" content="">
<meta name="description" content="">

<?php
$style = $_SERVER['HTTP_HOST']; 
$style = "includes/style.php"; 
include($style); 

$urhere = "homepage";
?>






</head>
<body class="copyrightchecker login">

<?php
$header = $_SERVER['HTTP_HOST']; 
$header = "includes/header.php"; 
include($header); 
?>




<section class="pading-60">
  <div class="container align-self-center">
    <div class="row">
        <div class="steps laststep">
          <h3>Please Login</h3>
          <div class="formdata_wrapper">
            <div class="databody">
              <div class="datacol-left">
                <form role = "form" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                    
                  <div class="datadrow">
                      <div class="form-group <?php echo (!empty($username_err)) ? 'has-error' : ''; ?>">
                    <label for="name">Enter Your Name</label>
                    <input name="username" type="text" placeholder="Username" value="<?php echo $username; ?>">
                    <span class="help-block"><?php echo $username_err; ?></span>
                  </div>

                  <div class="datadrow">
                      <div class="form-group <?php echo (!empty($password_err)) ? 'has-error' : ''; ?>">
                    <label for="password">Enter Your Password</label>
                    <input name="password" type="password" placeholder="Password">
                    <span class="help-block"><?php echo $password_err; ?></span>
                  </div>

                  <div class="datadrow">
                    <input type="submit" value="Login">
                  </div>

                </form>
                

                
              </div>
              
            </div>
          </div>
        </div>
    </div>
  </div>
</section>








<?php
$footer = $_SERVER['HTTP_HOST']; 
$footer = "includes/footer.php"; 
include($footer); 
?>



</body>
</html>