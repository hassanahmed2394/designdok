<?php
$mysql_hostname = "localhost";
$mysql_user = "gcpbbco_user";
$mysql_password = "Solution123+";
$mysql_database = "gcpbbco_wb";

$con = mysqli_connect($mysql_hostname,$mysql_user,$mysql_password,$mysql_database);

/*
// Check connection
if (mysqli_connect_errno()){ echo "Failed to connect to MySQL: " . mysqli_connect_error();}
else{ echo "connected";}
*/
?>