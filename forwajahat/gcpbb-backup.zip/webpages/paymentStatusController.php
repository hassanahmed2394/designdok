<?php
## CONFIG ##
include("connectiondb.php");

# LIST EMAIL ADDRESS
//$recipient = "forms@gcpbb.co.uk";

# SUBJECT (Subscribe/Remove)
//$subject = "Logo Order";
// $ebpage = "App development";

# RESULT PAGE
$location = "https://gcpbb.co.uk/payment-confirmation.php";

## FORM VALUES ##

# SENDER - WE ALSO USE THE RECIPIENT AS SENDER IN THIS SAMPLE
# DON'T INCLUDE UNFILTERED USER INPUT IN THE MAIL HEADER!
//$sender = "support@gcpbb.co.uk";




# MAIL BODY
$gcpbbcode = $_REQUEST['gcpbbcode'];
$paymentStatus = $_REQUEST['paymentstatus'];
//$subscriber_email = $_REQUEST['Email'];

//$subscriber_subject = "Your Brand is now verified and in our list - ".$gcbppcode;
//$subscriber_email_data = file_get_contents('https://gcpbb.co.uk/email/queryFormThankyou.html');





//print_r($_FILES);











if (mysqli_connect_errno()){  echo "Failed to connect to MySQL: " . mysqli_connect_error(); }
else{
    
    
    if($_SERVER["REQUEST_METHOD"] == "POST"){
        
       if ($_POST['paymentstatus'] === '1') {
           $sql = "UPDATE company_registration_tb SET paymentStatus='$paymentStatus' WHERE gcpbb_code = '$gcpbbcode'";
           
           

           
           
        }
        elseif ( $_POST['paymentstatus'] === '0' ) {
            $sql = "UPDATE company_registration_tb SET paymentStatus='$paymentStatus' WHERE gcpbb_code = '$gcpbbcode'";
        }
    }

mysqli_query($con,$sql);
mysqli_close($con);
}


## SHOW RESULT PAGE ##
header( "Location: $location" );




?>