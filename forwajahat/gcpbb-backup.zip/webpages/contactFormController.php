<?php
## CONFIG ##
include("connectiondb.php");

# LIST EMAIL ADDRESS
$recipient = "forms@gcpbb.co.uk";

# SUBJECT (Subscribe/Remove)
$subject = "Logo Order";
// $ebpage = "App development";

# RESULT PAGE
$location = "/thankyou.php";

## FORM VALUES ##

# SENDER - WE ALSO USE THE RECIPIENT AS SENDER IN THIS SAMPLE
# DON'T INCLUDE UNFILTERED USER INPUT IN THE MAIL HEADER!
$sender = "support@gcpbb.co.uk";

if (isset($_POST['Termscheck'])) {

    $termsCheck = "Yes";

} else {

   $termsCheck = "No";

}


function random_string($length) {
    $key = '';
    $keys = array_merge(range(0, 9), range('A', 'Z'));

    for ($i = 0; $i < $length; $i++) {
        $key .= $keys[array_rand($keys)];
    }

    return $key;
}

 



$gcbppcode = random_string(6);;

# MAIL BODY
$subscriber_email = $_REQUEST['Email'];
$subscriber_subject = "YOUR GCPBB CODE IS ".$gcbppcode;
$subscriber_email_data = file_get_contents('https://gcpbb.co.uk/email/queryFormThankyou.html');


//print_r($_REQUEST);

//print_r($_FILES);


if(isset($_REQUEST['hiddencapcha']) && $_REQUEST['hiddencapcha'] == "" ){
if(isset($_REQUEST['Name']) && $_REQUEST['Name'] != "" 
  && isset($_REQUEST['Email']) && $_REQUEST['Email'] != "" 
  && isset($_REQUEST['Number']) && $_REQUEST['Number'] != ""
  && isset($_REQUEST['Companyname']) && $_REQUEST['Companyname'] != ""
  && isset($_REQUEST['Industry']) && $_REQUEST['Industry'] != ""
  && isset($_REQUEST['DesignCompanyName']) && $_REQUEST['DesignCompanyName'] != ""
  && isset($_REQUEST['Titledesign']) && $_REQUEST['Titledesign'] != ""
  && isset($_REQUEST['Preffered_medium_one']) && $_REQUEST['Preffered_medium_one'] != ""
  && isset($_REQUEST['Meeting_time']) && $_REQUEST['Meeting_time'] != ""){
      
      
      
$body .= "Name: ".$_REQUEST['Name']." \n";
$body .= "Email: ".$_REQUEST['Email']." \n";
$body .= "Number: ".$_REQUEST['Number']." \n";
$body .= "Company Name: ".$_REQUEST['Companyname']." \n";
$body .= "Industry: ".$_REQUEST['Industry']." \n";
$body .= "Design's Company Name: ".$_REQUEST['DesignCompanyName']." \n";
$body .= "Title of Your design: ".$_REQUEST['Titledesign']." \n";
$body .= "Caption: ".$_REQUEST['Caption']." \n";
$body .= "UniqueFeatures: ".$_REQUEST['UniqueFeatures']." \n";
$body .= "1st preferred medium of communication: ".$_REQUEST['Preffered_medium_one']." \n";
$body .= "2nd preferred medium of communication: ".$_REQUEST['Preffered_medium_two']." \n";
$body .= "Prefer Time to Call: ".$_REQUEST['Meeting_time']." \n";
$body .= "Agrees with Terms and policy: ".$termsCheck." \n";
$body .= "GCPBB code: ".$gcbppcode." \n";



// $body .= "PublishingGoals: ".$checkPublishingGoal." \n";

if($_FILES["file"]["error"]>0)
{
    echo "FILE ERROR";
    die();
}
// $filename = "FOLDER/".$_FILES["file"]["name"];

 $info = pathinfo($_FILES['wordfile']['name']);
$ext = $info['extension']; // get the extension of the file
$newname = time().'.'.$ext; 

$target = '../Folder/'.$newname;

// move file to a folder
if (!move_uploaded_file($_FILES["wordfile"]["tmp_name"], $target)) { 
    //  echo "Sorry, there was an error uploading your file.";
    //  die();
    $target = 'No file attached';
 }

$trimedtarget = 'https://gcpbb.co.uk/Folder/'.$newname;
$body .= "file: ".$trimedtarget." \n";





if (mysqli_connect_errno()){  echo "Failed to connect to MySQL: " . mysqli_connect_error(); }
else{ $sql = 'insert into company_registration_tb (name,email,phone,companyname,industry,DesignCompanyName,Titledesign,Caption,UniqueFeatures,Preffered_medium_one,Preffered_medium_two,meeting_time,agreeWithPolicy,gcpbb_code,uploaded_file_URL) values ("'.$_REQUEST['Name'].'","'.$_REQUEST['Email'].'","'.$_REQUEST['Number'].'","'.$_REQUEST['Companyname'].'","'.$_REQUEST['Industry'].'","'.$_REQUEST['DesignCompanyName'].'","'.$_REQUEST['Titledesign'].'","'.$_REQUEST['Caption'].'","'.$_REQUEST['UniqueFeatures'].'","'.$_REQUEST['Preffered_medium_one'].'","'.$_REQUEST['Preffered_medium_two'].'","'.$_REQUEST['Meeting_time'].'","'.$_REQUEST['Termscheck'].'","'.$gcbppcode.'","'.$trimedtarget.'")';

mysqli_query($con,$sql);
mysqli_close($con);
}


$headers = "From: " . $sender . "\r\n";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
# add more fields here if required
## SEND MESSGAE ##

mail( $recipient, $subject, $body,   "From: $sender" ) or die ("Mail could not be sent.");
mail( $subscriber_email, $subscriber_subject, $subscriber_email_data, $headers) or die ("Unable to send email to subscriber");

## SHOW RESULT PAGE ##
header( "Location: $location" );


  }

    
}


?>