<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Terms and Conditions</title>
<?php
$style = $_SERVER['HTTP_HOST']; 
$style = "includes/style.php"; 
include_once($style); 
?>
</head>
<body class="inner-pages policypg">
<?php
$header = $_SERVER['HTTP_HOST']; 
$header = "includes/header.php"; 
include_once($header); 
?>

<section class="sec-padding ">
  <div class="container">
    <div class="row">
      <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 center">
        <h2>Terms & Conditions</h2>
        <!-- <ul class="termslist">
          <li><a href="">Disclaimer</a></li>
          <li><a href="">Payment Policy</a></li>
          <li><a href="">Delivery Policy</a></li>
          <li><a href="">Member Area</a></li>
          <li><a href="">Customer Support</a></li>
        </ul> -->
      </div>
    </div>
    <div class="row">
      <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <h4>Disclaimer</h4>
        <p>Information on GCPBB's website is intended as a introduction to the ideas of copyright and intellectual property rights only, it should not be regarded as a legal advice or opinion.
          <br>While we make reasonable efforts to ensure that the data presented is both accurate and honest, we cannot accept any liability regarding the accuracy or completeness of information, or its application under specific national laws.</p>

        
        <h4>Payment Policy</h4>
        <p>Payment is due at the time of copyright registration: For our online transactions, payment is taken as the last step of the online registration process. To help prevent scam we cannot allow credit/debit card payments to be split across multiple cards.</p>

        <h4>Delivery Policy</h4>
        <p>Our clients shall receive their brand's sealed copyright certificate in their Member Area within 7 business days. If the client chooses to terminate the copyright registration process after payment, uploaded logo design files cannot normally be returned, and payment will not be refunded for any such termination.</p>

        <h4>Member Area</h4>
        <p>The Member Area is a convenient way to communicate with our clients. It is your sole responsibility to check your member area, by your distinct log-in id and password to address any queries, concerns, or additional instructions you may want GCPBB to follow. However, if you are uncertain how to use this area, you may contact GCPBB's customer support team any time for assistance.</p>

        <h4>Customer Support</h4>
        <ul class="pointslist">
          <li>GCPBB offers 24-hours customer support to address your queries and questions.</li>
          <li>You can contact our customer care agents any time and we guarantee to respond immediately.</li>
        </ul>
        

        

        
        
      </div>
    </div>
  </div>
</section>
<?php
$footer = $_SERVER['HTTP_HOST']; 
$footer = "includes/footer.php"; 
include_once($footer); 
?>
</body>
</html>