<!doctype html>
<html lang="en">
<head>
<title>Start a Business, Protect Your Brand, Trademark Incorporate & More Online | gcpbb.co.uk | Global Copyrights Protection Bureau for Brands</title>
<meta name="keywords" content="">
<meta name="description" content="">

<?php
$style = $_SERVER['HTTP_HOST']; 
$style = "includes/style.php"; 
include($style); 
?>

<?php
$urhere = "services";
?>


</head>
<body class="inner-pages innerservices">

<?php
$header = $_SERVER['HTTP_HOST']; 
$header = "includes/header.php"; 
include($header); 
?>



<section class="innerbanner inb-two  d-flex" style="background-image:url(assets/images/banners/trademark-registration.png)">
  <div class="container align-self-center">
    <div class="row">
      <div class="col-lg-12">
        <div class="text-wrap">
          <p>Attorney-Led Trademark Registration</p>
          <h5>For your mark. Get set with an attorney. Go.</h5>
          <p>Enlist an experienced attorney so that you have the freedom to run your business.</p>
          <a href="javascript:;" class="bg">Start my application</a>
          <p class="sml">Pricing starts at £599 + government filing fee</p>
          <!-- <ul>
            <li><a href="javascript:;">See details</a></li>
            <li><a href="javascript:;">View sample</a></li>
          </ul> -->
        </div>
      </div>
    </div>
  </div>
</section>










<section class="belowbannerwapper">
  <div class="container">
    <div class="row">
      <div class="topwrapper">
        <h2>How it works</h2>
        <p>For a more detailed view of our process, <a href="javascript:;">click here</a></p>
      </div>
      <div class="bblist">
        <div class="item col4">
          <figcaption>
            <img src="assets/images/checklist.png">
          </figcaption>
          <h4>1. Complete our simple online questionnaire</h4>
          <p>Complete our simple questionnaire. If you need technical assistance at any time, our customer care specialists are available to help.</p>
        </div>

        <div class="item col4">
          <figcaption>
            <img src="assets/images/documents.png">
          </figcaption>
          <h4>2. We conduct a Peace of Mind Review™</h4>
          <p>Your Application is Created and Reviewed Our LegalZip® system creates your Provisional Application for Patent. For your convenience, we can even create your technical drawings and perform a patent search. As an option, you can have your application reviewed by a patent professional.</p>
        </div>

        <div class="item col4">
          <figcaption>
            <img src="assets/images/mail-doc.png">
          </figcaption>
          <h4>3. We electronically file your application with the USPTO</h4>
          <p>Complete the Provisional Application for Patent questionnaire. If you need technical assistance at any time, our customer care specialists are available to help.</p>
        </div>
      </div>
    </div>
  </div>
</section>






<?php
$patentpackage = $_SERVER['HTTP_HOST']; 
$patentpackage = "includes/tradepackage.php"; 
include($patentpackage); 
?>



<?php
$askawaywrapper = $_SERVER['HTTP_HOST']; 
$askawaywrapper = "includes/inner-askawaywrapper.php"; 
include($askawaywrapper); 
?>

<section class="startwrapper">
  <div class="container">
    <div class="row">
      <div class="topwrapper">
        <h2>Start my Provisional Application for Patent now</h2>
        <a href="javascript:;">Start my application</a>
      
      </div>
    </div>
  </div>
</section>



        
          









<?php
$footer = $_SERVER['HTTP_HOST']; 
$footer = "includes/footer.php"; 
include($footer); 
?>




<!-- scroll top car
<div class="car-top"><span>
<img src="assets/images/car.png" alt="Top" title="Back to top" />
</span></div>
-->
</body>
</html>