<!doctype html>
<html lang="en">
<head>
<title>Hire us to Get Started! Reseller Prohub is the way to go. - ResellerProhub</title>

<meta name="keywords" content="">
<meta name="description" content="">

<?php
$style = $_SERVER['HTTP_HOST']; 
$style = "includes/style.php"; 
include_once($style); 
?>




</head>
<body class="gtstarted">

<section class="tphead">
  <div class="container">
    <div class="row">
      <div class="col-lg-3">
        <div class="logo">
            <a href="/">
              <img class="img-fluid black" src="assets/images/glogo.svg" alt="*" />
            </a>
          </div>
      </div>
      <div class="col-lg-9">
        <div class="text-right">
          <a href="/"><span class="icon-x-square"></span></a>
        </div>
      </div>
    </div>
  </div>
</section>


<div class="slider-wrapper black">
  <section class="">
    <div class="item">
      <div class="home-banner " style="background:#fff;height: 100vh;">
        <div class="container ">
          <div class="row">
            <div class=" col-lg-12 col-xl-12 text-center">
              <div class="home-banner-content">
                <div class="col-lg-8 offset-lg-2   inner-content  text-left">
                    <div class="form-box-main clearfix">
                      <h2>We would like to hear from you</h2>
                      <p>Heads up! We require that you sign up for a Reseller Prohub services and packages. We make all your dreams come true in a successful project.</p>
                      <form class="cmxform" id="contactForm"  method="POST" action="webpages/getstartdController.php"  enctype="multipart/form-data">
                        <div class="row">
                          <div class="col-md-12">
                            <label class="field-txt">Name <span>*</span></label>
                              <input id="username" name="Name" minlength="2" type="text" placeholder="" required />
                         </div>
                          <div class="col-md-6">
                            <label class="field-txt">Email <span>*</span></label>
                            <input id="cemail" type="email" name="Email" placeholder="" required>
                         </div>
                         <div class="col-md-6">
                            <label class="field-txt">Phone Number<span>*</span></label>
                           <input id="phone-country" name="Number" type="number" placeholder="" required/>
                         </div>

                         <div class="col-md-12">
                             <div class="forarrowselect">
                                <label class="field-txt">Select Package <span>*</span></label>

                                <select name="Package" id="packages" class="valid safari_only" aria-invalid="false" >
                                  <option  value="" pack="0">Select Package</option>
                                  <option  value="Trade Mark - £1999" pack="1">Trade Mark - £1999</option>
                                  <option  value="Copyrights - £499" pack="2">Copyrights - £499</option>
                                  <option  value="Patent - £299" pack="3">Patent - £299</option>
                                </select>
                            </div>
                         </div>
                         

                        <div class="col-md-12">
                            <label class="field-txt">Additional Comments <span>*</span></label>
                            <textarea name="Comment" placeholder="" /></textarea>
                         </div>
                         
                        <div class="col-md-12">
                            <input class="submit" type="submit" value="Submit" />
                            <input class="" type="hidden" name="ctry" value="" />
                              <input type="hidden" name="pc" value="">
                              <input type="hidden" name="hiddencapcha" value="">
                         </div>
                         </div>
                      </form>
                    </div>




        
                </div>

                
            </div>
          </div>
        </div>
      </div>
    </div>
    
  </section>
  <!-- <div class="slider-progress">
    <div class="progress"></div>
  </div> -->
</div>                
                
    






<script src="assets/js/mlib.js"></script> 
<script src="assets/js/functions.js"></script> 



<!-- scroll top car
<div class="car-top"><span>
<img src="assets/images/car.png" alt="Top" title="Back to top" />
</span></div>
-->
</body>
</html>