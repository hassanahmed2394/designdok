<!doctype html>
<html lang="en">
<head>
<title>Thank You! We've Noted That Down | SEO PRO HUB</title>
<meta name="description" content="Thankyou for the information that you just submitted to us! We've noted it down and will get back to you soon." />

<?php
$style = $_SERVER['HTTP_HOST']; 
$style = "includes/style.php"; 
include_once($style); 
?>


<style>
  .tphead{background: #f7f9fc;}
  .home-banner .home-banner-content p {color: #555;}
  .slider-wrapper{margin-top: 0;}
</style>

</head>
<body class="analyzepg">

<section class="tphead">
  <div class="container">
    <div class="row">
      <div class="col-lg-2">
        <div class="logo">
            <a href="/">
              <img class="img-fluid black" src="assets/images/glogo.svg" alt="*" />
            </a>
          </div>
      </div>
      <div class="col-lg-10">
        <div class="text-right">
          <a href="/"><span class="icon-x-square" style="font-size: 28px;"></span></a>
        </div>
      </div>
    </div>
  </div>
</section>


<div class="slider-wrapper black">
  <section class="">
    <div class="item">
      <div class="home-banner d-flex" style="background:#f7f9fc; height: 100vh;">
        <div class="container align-self-center">
          <div class="row">
            <div class=" col-lg-12 col-xl-12 text-center">
              <div class="home-banner-content">
                <h1>Thank You! <br>We've Noted That Down</h1>
                <p class="subtitle">Thankyou for the information that you just submitted to us! <br> We've noted it down and will get back to you soon.</p>
                
                

                
            </div>
          </div>
        </div>
      </div>
    </div>
    
  </section>
  <!-- <div class="slider-progress">
    <div class="progress"></div>
  </div> -->
</div>                
                
    






<script src="assets/js/mlib.js"></script> 
<script src="assets/js/functions.js"></script> 



<!-- scroll top car
<div class="car-top"><span>
<img src="assets/images/car.png" alt="Top" title="Back to top" />
</span></div>
-->
</body>
</html>